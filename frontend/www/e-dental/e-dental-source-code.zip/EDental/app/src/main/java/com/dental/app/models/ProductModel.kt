package com.dental.app.models

data class ProductModel(
    val serviceName : String? = "",
    val serviceDes : String? = "",
)
