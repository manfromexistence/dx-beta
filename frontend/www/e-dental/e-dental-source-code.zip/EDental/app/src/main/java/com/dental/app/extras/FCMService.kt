package com.dental.app.extras

import android.app.Service
import com.google.firebase.messaging.FirebaseMessagingService

class FCMService : FirebaseMessagingService() {



}