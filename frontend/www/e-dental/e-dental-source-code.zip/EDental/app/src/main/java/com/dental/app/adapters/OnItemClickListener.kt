package com.dental.app.adapters

interface OnItemClickListener {
    fun onItemClick(position : Int)
}