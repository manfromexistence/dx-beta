package com.dental.app.models

data class DentistModel(
    val name : String? = "",
    val surname : String? = "",
    val uuid : String? = "",
)
