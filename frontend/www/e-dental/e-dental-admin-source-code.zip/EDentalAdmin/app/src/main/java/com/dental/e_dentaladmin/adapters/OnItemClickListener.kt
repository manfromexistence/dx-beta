package com.dental.e_dentaladmin.adapters

interface OnItemClickListener {
    fun onItemClick(position : Int)
}